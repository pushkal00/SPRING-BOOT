package com.car.Exception;

public class InvalidNameExp extends RuntimeException{

}
