package com.car.Exception;

public class InvalidIdException extends RuntimeException{

}
