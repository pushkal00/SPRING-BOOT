package com.car.demo.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.car.Exception.InvalidNameExp;
import com.car.demo.dao.CarDAO;
import com.car.demo.dto.Car;
@Transactional
@Service
public class CarServiceImpl implements CarService {
	@Autowired
	CarDAO carref;
	
	@Override
	public List<Car> findAll() {
		
		return carref.findAll();
	}

	@Override
	public Car findById(int id) {
		
		return carref.findById(id);
	}

	@Override
	public Car create(Car car) {
		String nm=car.getMake();
		Pattern pt=Pattern.compile("^[a-zA-Z]*$");
		Matcher mat=pt.matcher(nm);
		boolean r=mat.find();
		if(r==false)
			throw new InvalidNameExp();
		return carref.create(car);
	}

	@Override
	public Car update(Car car) {
		
		return carref.update(car);
	}

	@Override
	public Car delete(int id) {
	
		return carref.delete(id);
	}

}
