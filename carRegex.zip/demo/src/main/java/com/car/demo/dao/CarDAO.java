package com.car.demo.dao;

import java.util.List;

import com.car.demo.dto.Car;

public interface CarDAO {

	public List<Car> findAll();

	public Car findById(int id);

	public Car create(Car car);

	public Car update(Car car);

	public Car delete(int id);

}
