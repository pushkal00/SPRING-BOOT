package com.car.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.car.Exception.InvalidIdException;
import com.car.Exception.InvalidNameExp;
import com.car.demo.dao.CarDAO;
import com.car.demo.dto.Car;
import com.car.demo.service.CarService;

@RestController
@RequestMapping("/car/v1")
public class CarController {
	@Autowired
	//private CarDAO carRef;
	private CarService carRef;
	
	@RequestMapping(method=RequestMethod.GET, value="car")
	public List<Car> list(){
		return carRef.findAll();
		
	}
	@RequestMapping(method=RequestMethod.GET, value="car/{id}")
	public Car findBy(@PathVariable(name="id") int id){
		return carRef.findById(id);
		
	}
	@RequestMapping(method=RequestMethod.POST, value="car")
	public Car create(@RequestBody Car car) {
		return carRef.create(car);
	}
	@RequestMapping(method=RequestMethod.PUT,value="car/{id}")
	public Car update(@RequestBody Car car,@PathVariable(name="id") int id) {
		return carRef.update(car);
	}
	@RequestMapping(method=RequestMethod.DELETE,value="car/{id}")
	public Car delete(@PathVariable(name="id") int id)
	{
		return carRef.delete(id);
	}
	
    @ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Invalid ID")
    @ExceptionHandler({InvalidIdException.class})
    public void giveexception()
    {
    	
    }
    
    @ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Invalid name")
    @ExceptionHandler({InvalidNameExp.class})
    public void namexception()
    {
    	
    }
}
