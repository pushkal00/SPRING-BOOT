package com.car.demo.service;

import java.util.List;

import com.car.demo.dto.Car;

public interface CarService {

	
	public List<Car> findAll();

	public Car findById(int id);

	public Car create(Car car);

	public Car update(Car car);

	public Car delete(int id);
}
