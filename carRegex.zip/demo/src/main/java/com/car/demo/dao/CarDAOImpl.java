package com.car.demo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.car.Exception.InvalidIdException;
import com.car.demo.dto.Car;
@Repository
@Transactional
public class CarDAOImpl implements CarDAO {
	@PersistenceContext
	private EntityManager entitymanager;
	
	

	@Override
	public List<Car> findAll() {
		Query query=entitymanager.createQuery("select car from Car car");
		return query.getResultList();
	}

	@Override
	public Car findById(int id) {
		
				Car c=entitymanager.find(Car.class, id);
				if(c==null)
					throw new InvalidIdException();
					return c;
	}

	@Override
	@Transactional
	public Car create(Car car) {
		entitymanager.persist(car);
		return car;
	}

	@Override
	public Car update(Car car) {
		/**/
		return entitymanager.merge(car);
	}

	@Override
	public Car delete(int id) {
		Car car=entitymanager.find(Car.class, id);
		entitymanager.remove(car);
		return car;
	}

}
