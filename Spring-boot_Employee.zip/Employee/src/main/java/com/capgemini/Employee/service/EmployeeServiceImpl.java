package com.capgemini.Employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Employee.dto.Employee;
import com.capgemini.Employee.repo.IEmployeeRepo;
@Service
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	IEmployeeRepo repo;

	@Override
	public List<Employee> list() {
		return repo.list();
		//return null;
	}

	@Override
	public Employee create(Employee wreck) {
		return repo.create(wreck);
	}

	@Override
	public Employee get(Long id) {
		return repo.get(id);
	}

	@Override
	public Employee update(Long id, Employee wreck) {
		return repo.update(id, wreck);
	}

	@Override
	public Employee delete(Long id) {
		return repo.delete(id);
	}
	
	

}
