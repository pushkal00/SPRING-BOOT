package com.capgemini.Employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Employee.dto.Employee;
import com.capgemini.Employee.service.IEmployeeService;
/*@ComponentScan("com.capgemini")
@EntityScan("com.capgemini")*/
@RestController
public class EmployeeController {
	@Autowired
	IEmployeeService serv;
	
	@RequestMapping(method=RequestMethod.GET,value="/GetMeList")
	public List<Employee> list()
	{
		return serv.list();
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/upd/{id}")
	public Employee update(@RequestBody Employee e,@PathVariable(name="id") long id)
	{
		return serv.update(id, e);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/Post")
	public Employee create(@RequestBody Employee e)
	{
		return serv.create(e);
	}
	@RequestMapping(method=RequestMethod.GET,value="/GetMeList/{id}")

	public Employee get(@PathVariable(name="id")Long id) {
		// TODO Auto-generated method stub
		return serv.get(id);
		}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/Delete/{id}")
	public Employee delete(@PathVariable(name="id")Long id) {
		
	return serv.delete(id);	
	}


}
