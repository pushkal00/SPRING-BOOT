package com.capgemini.Employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.Employee.repo.EmployeeRepoImpl;
import com.capgemini.Employee.repo.IEmployeeRepo;
import com.capgemini.Employee.dto.Employee;
public interface IEmployeeService {
	
	public List<Employee> list();
	public Employee create(Employee wreck) ;
	public Employee get(Long id);
	public Employee update(Long id, Employee wreck);
	public Employee delete(Long id);
 
	
	
	
	
	
	

}
