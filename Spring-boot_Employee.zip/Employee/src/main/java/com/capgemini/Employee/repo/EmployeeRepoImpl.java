package com.capgemini.Employee.repo;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.capgemini.Employee.dto.Employee;
@Repository
@Transactional
public class EmployeeRepoImpl implements IEmployeeRepo{
	
	@PersistenceContext
	EntityManager manager;

	@Override
	//@RequestMapping(value="/getMeList", method=RequestMethod.GET)
	public List<Employee> list() {
		// TODO Auto-generated method stub
		manager.flush();
		Query query = manager.createQuery("select emp from Employee emp");
		List<Employee> list = query.getResultList();
		for(Employee e : list)
			System.out.println(e.getEname()+" "+" "+e.getAddress()+" "+" "+e.getId()+" "+" "+e.getLeaves_avail());
		System.out.println("lop");
		
		return list;
	}

	@Override
	public Employee create(Employee wreck) {
		manager.persist(wreck);
		return wreck;
	}

	@Override
	public Employee get(Long id) {
		// TODO Auto-generated method stub
		//Query query = manager.createQuery(arg0)
		Employee emp=manager.find(Employee.class,id);
		return emp;
	}

	@Override
	public Employee update(Long id, Employee e) {
		// TODO Auto-generated method stub
		e.setId(id);
		manager.merge(e);
		manager.flush();
		System.out.println("Inside Update Function");
		return e;
	}

	@Override
	public Employee delete(Long id) {
		// TODO Auto-generated method stub
		Employee emp=get(id);
		manager.remove(emp);
		return emp;
	}

}
