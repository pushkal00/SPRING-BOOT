package com.capgemini.practicedemo.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.practicedemo.dto.Shipwreck;

@Repository
@Transactional
public class ShipwreckRepoImpl implements ShipWreckRepo {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Shipwreck> list() {
		Query query = entityManager.createQuery("select wreck from Shipwreck wreck");
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional
	public Shipwreck create(Shipwreck wreck) {
		entityManager.persist(wreck);
		// TODO Auto-generated method stub
		
		/*entityManager.persist(wreck);*/
		return wreck;
	}

	@Override
	public Shipwreck get(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shipwreck update(Long id, Shipwreck wreck) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shipwreck delete(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
