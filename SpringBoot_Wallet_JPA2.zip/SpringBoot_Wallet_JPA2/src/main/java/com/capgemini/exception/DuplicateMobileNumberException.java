package com.capgemini.exception;

public class DuplicateMobileNumberException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	

	
}
