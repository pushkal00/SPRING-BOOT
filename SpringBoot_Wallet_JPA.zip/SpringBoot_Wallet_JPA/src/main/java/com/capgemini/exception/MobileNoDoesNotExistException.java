package com.capgemini.exception;

public class MobileNoDoesNotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MobileNoDoesNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
