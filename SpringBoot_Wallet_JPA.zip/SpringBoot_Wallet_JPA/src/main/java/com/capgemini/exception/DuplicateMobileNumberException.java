package com.capgemini.exception;

public class DuplicateMobileNumberException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DuplicateMobileNumberException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
