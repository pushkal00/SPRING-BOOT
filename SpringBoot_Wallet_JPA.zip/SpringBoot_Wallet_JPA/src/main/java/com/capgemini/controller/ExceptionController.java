package com.capgemini.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.capgemini.exception.DuplicateMobileNumberException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.exception.MobileNoDoesNotExistException;

public class ExceptionController extends ResponseEntityExceptionHandler {

	@ExceptionHandler(value = DuplicateMobileNumberException.class)
	public ResponseEntity<Object> AlredyRegisteredexception(MobileNoDoesNotExistException ex)
	{
		return new ResponseEntity<>("Mobile Number Already registered", HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(value = InsufficientAmountException.class)
	public ResponseEntity<Object> InsufficientException(InsufficientAmountException ex)
	{
		return new ResponseEntity<>("Insufficient Balance Exception", HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(value =MobileNoDoesNotExistException.class)
	public ResponseEntity<Object> exception(MobileNoDoesNotExistException ex)
	{
		return new ResponseEntity<>("Mobile Number Not found Exception", HttpStatus.NOT_FOUND);
	}
	
	 @Override
	  protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
	      HttpHeaders headers, HttpStatus status, WebRequest request) {
	   
	    return new ResponseEntity<>(ex.getBindingResult().getAllErrors().get(0).getDefaultMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	  } 
}
