package com.capgemini.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bean.Customer;
import com.capgemini.exception.DuplicateMobileNumberException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.exception.MobileNoDoesNotExistException;
import com.capgemini.service.WalletServiceImpl;

@RestController
public class CustomerController {

	@Autowired
	WalletServiceImpl walletServiceImpl;

	Customer customer;

	@RequestMapping(method = RequestMethod.POST, value = "/addCustomer")
	public ResponseEntity<Object> createAccount(@Valid @RequestBody Customer cus) throws DuplicateMobileNumberException {

		Customer cus1 =  walletServiceImpl.createAccount(cus.getName(), cus.getMobileNo(), cus.getWallet().getBalance());
		
		return new ResponseEntity<Object>(cus1,HttpStatus.OK);

	}

	@RequestMapping(method = RequestMethod.GET, value = "/getBalance/{mobileNo}")

	public ResponseEntity<Object> showBalance(@PathVariable String mobileNo) throws MobileNoDoesNotExistException {
		Customer cus =  walletServiceImpl.showBalance(mobileNo);

		return new ResponseEntity<Object>(cus,HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/depositBalance/{mobileNo}/{amount}")

	public ResponseEntity<Object> depositBalance(@PathVariable String mobileNo, @PathVariable BigDecimal amount)
			throws MobileNoDoesNotExistException {
		Customer cus = walletServiceImpl.depositAmount(mobileNo, amount);
		return new ResponseEntity<Object>(cus,HttpStatus.OK);

	}

	@RequestMapping(method = RequestMethod.POST, value = "/withdrawBalance/{mobileNo}/{amount}")

	public ResponseEntity<Object> withdrawBalance(@PathVariable String mobileNo, @PathVariable BigDecimal amount)
			throws MobileNoDoesNotExistException, InsufficientAmountException {
		Customer cus = walletServiceImpl.withdrawAmount(mobileNo, amount);
		return new ResponseEntity<Object>(cus,HttpStatus.OK); 

	}

	@RequestMapping(method = RequestMethod.POST, value = "/fundTransfer/{sourceMobileNo}/{targetMobileNo}/{amount}")

	public ResponseEntity<Object> fundTransfer(@PathVariable String sourceMobileNo, @PathVariable String targetMobileNo,
			@PathVariable BigDecimal amount) throws MobileNoDoesNotExistException, InsufficientAmountException {

		List<Customer> cus = new ArrayList<Customer>();
		cus = walletServiceImpl.fundTransfer(sourceMobileNo, targetMobileNo, amount);
		return new ResponseEntity<Object>(cus,HttpStatus.OK);

	}

}
